local t = require("opcua.types_gen")

t.AttributeId = {
  Invalid = 0,
  NodeId = 1,
  NodeClass = 2,
  BrowseName = 3,
  DisplayName = 4,
  Description = 5,
  WriteMask = 6,
  UserWriteMask = 7,
  IsAbstract = 8,
  Symmetric = 9,
  InverseName = 10,
  ContainsNoLoops = 11,
  EventNotifier = 12,
  Value = 13,
  DataType = 14,
  Rank = 15,
  ArrayDimensions = 16,
  AccessLevel = 17,
  UserAccessLevel = 18,
  MinimumSamplingInterval = 19,
  Historizing = 20,
  Executable = 21,
  UserExecutable = 22,
  DataTypeDefinition = 23,
  RolePermissions = 24,
  UserRolePermissions = 25,
  AccessRestrictions = 26,
  AccessLevelEx = 27,
  Max = 27
}

t.VariantType = {
  Null = 0,
  Boolean = 1,
  SByte = 2,
  Byte = 3,
  Int16 = 4,
  UInt16 = 5,
  Int32 = 6,
  UInt32 = 7,
  Int64 = 8,
  UInt64 = 9,
  Float = 10,
  Double = 11,
  String = 12,
  DateTime = 13,
  Guid = 14,
  ByteString = 15,
  XmlElement = 16,
  NodeId = 17,
  ExpandedNodeId = 18,
  StatusCode = 19,
  QualifiedName = 20,
  LocalizedText = 21,
  ExtensionObject = 22,
  DataValue = 23,
  Variant = 24,
  DiagnosticInfo = 25
}

t.SecurityPolicy = {
  None = "http://opcfoundation.org/UA/SecurityPolicy#None",
  Basic128Rsa15 = "http://opcfoundation.org/UA/SecurityPolicy#Basic128Rsa15",
  Aes128_Sha256_RsaOaep = "http://opcfoundation.org/UA/SecurityPolicy#Aes128_Sha256_RsaOaep",
  Basic256Sha256 = "http://opcfoundation.org/UA/SecurityPolicy#Basic256Sha256",
  Aes256_Sha256_RsaPss = "http://opcfoundation.org/UA/SecurityPolicy#Aes256_Sha256_RsaPss",
  PubSub_Aes128_CTR = "http://opcfoundation.org/UA/SecurityPolicy#PubSub-Aes128-CTR",
  PubSub_Aes256_CTR = "http://opcfoundation.org/UA/SecurityPolicy#PubSub-Aes256-CTR"
}

t.TranportProfileUri = {
  TcpBinary   = "http://opcfoundation.org/UA-Profile/Transport/uatcp-uasc-uabinary",
  HttpsBinary = "http://opcfoundation.org/UA-Profile/Transport/https-uabinary",
  HttpsJson   = "http://opcfoundation.org/UA-Profile/Transport/https-uajson",
  MqttBinary  = "http://opcfoundation.org/UA-Profile/Transport/pubsub-mqtt-uadp",
  MqttJson    = "http://opcfoundation.org/UA-Profile/Transport/pubsub-mqtt-json"
}

t.ServerProfile = {
  NanoEmbedded2017 = "http://opcfoundation.org/UA-Profile/Server/NanoEmbeddedDevice2017"
}

t.IssuedTokenType = {
  Azure = "http://opcfoundation.org/UA/UserToken#Azure",
  JWT = "http://opcfoundation.org/UA/Authorization#JWT",
  OAuth2 = "http://opcfoundation.org/UA/Authorization#OAuth2",
  OPCUA = "http://opcfoundation.org/UA/Authorization#OPCUA"
}

t.ValueRank = {
  ScalarOrOneDimension = -3,
  Any = -2,
  Scalar = -1,
  OneOrMoreDimensions = 0,
  OneDimension = 1,
  -- Number of dimensions are valid: 2(matrix),3,4..
}

local m = t.NodeAttributesMask

t.CommonAttributesMask = m.DisplayName | m.Description | m.WriteMask | m.UserWriteMask

t.ObjectAttributesMask = t.CommonAttributesMask | m.EventNotifier

t.ObjectTypeAttributesMask = t.CommonAttributesMask | m.IsAbstract

t.VariableAttributesMask = t.CommonAttributesMask | m.Value |
                           m.DataType | m.ValueRank | m.ArrayDimensions |
                           m.AccessLevel | m.UserAccessLevel | m.MinimumSamplingInterval |
                           m.Historizing

t.VariableTypeAttributesMask = t.CommonAttributesMask | m.Value |
                           m.DataType | m.ValueRank | m.ArrayDimensions | m.IsAbstract

t.MethodAttributesMask = t.CommonAttributesMask | m.Executable | m.UserExecutable

t.ReferenceTypeAttributesMask = t.CommonAttributesMask | m.IsAbstract | m.Symmetric | m.InverseName

t.DataTypeAttributesMask = t.CommonAttributesMask | m.IsAbstract

t.ViewAttributesMask = t.CommonAttributesMask | m.ContainsNoLoops | m.EventNotifier

t.ReferenceType = {
NonHierarchicalReferences = "i=32",
HierarchicalReferences = "i=33",
HasChild = "i=34",
Organizes = "i=35",
HasEventSource = "i=36",
HasModellingRule = "i=37",
HasEncoding = "i=38",
HasDescription = "i=39",
HasTypeDefinition = "i=40",
GeneratesEvent = "i=41",
Aggregates = "i=44",
HasSubtype = "i=45",
HasProperty = "i=46",
HasComponent = "i=47",
HasNotifier = "i=48",
HasOrderedComponent = "i=49",
FromState = "i=51",
ToState = "i=52",
HasCause = "i=53",
HasEffect = "i=54",
HasHistoricalConfiguration = "i=56",
}

t.DataTypeId = {
  Boolean = "i=1",
  SByte = "i=2",
  Byte = "i=3",
  Int16 = "i=4",
  UInt16 = "i=5",
  Int32 = "i=6",
  UInt32 = "i=7",
  Int64 = "i=8",
  UInt64 = "i=9",
  Float = "i=10",
  Double = "i=11",
  DateTime = "i=13",
  String = "i=12",
  ByteString = "i=15",
  Guid = "i=14",
  XmlElement = "i=16",
  NodeId = "i=17",
  ExpandedNodeId = "i=18",
  QualifiedName = "i=20",
  LocalizedText = "i=21",
  StatusCode = "i=19",
  Structure = "i=22",
  Variant = "i=24",
  Number = "i=26",
  Integer = "i=27",
  UInteger = "i=28",
  Enumeration = "i=29"
}

-- BitMask of access rights
t.AccessLevel = {
  CurrentRead = 1,
  CurrentWrite = 2,
  CurrentReadWrite = 3,
  HistoryRead =4,
  HistoryWrite = 8,
  SemanticChange = 16,
  StatusWrite = 32,
  TimestampWrite = 64,
}

return t
