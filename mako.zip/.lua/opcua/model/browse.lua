local ua = require("opcua.api")
local address_space_create = require("opcua.model.address_space")

local copy = ua.Tools.copy
local tins = table.insert
local tremove = table.remove

local HasTypeDefinition = "i=40"
local HasProperty = "i=46"
local HasComponent = "i=47"
local Organizes = "i=35"
local HasSubtype = "i=45"
local HasEncoding = "i=38"

local BaseObjectTypeNodeId = "i=58"
local BaseDataVariableType = "i=63"
local RootNodeId = "i=84"
local FolderTypeId = "i=61"

local PropertyTypeIdNodeId = "i=68"
local ArgumentTypeNodeId = "i=296"

local function createQualifiedName(name)
  if type(name) == "string" then
    name = {Name = name}
  elseif not ua.Tools.qualifiedNameValid(name) then
    error(ua.StatusCode.BadBrowseNameInvalid)
  end
  return name
end

local function createBaseNode(model, nodes, nodeClass, browseName, nodeId)
  nodeId = nodeId or model:newNodeId()
  browseName = createQualifiedName(browseName)

  local node = nodes:newNode(nodeId, nodeClass)
  node.Attrs.BrowseName = browseName
  node.Attrs.DisplayName = {Text = browseName.Name}
  return node
end

local function getVariableDataTypeId(variant)
  if not variant then
    return BaseDataVariableType
  end
  if variant.Type == ua.VariantType.ExtensionObject then
    if variant.IsArray and variant.Value and variant.Value[1] then
      return variant.Value[1].TypeId
    elseif variant.Value then
      return variant.Value.TypeId
    end
    return BaseDataVariableType
  end
  return ua.Tools.getVariantTypeId(variant)
end

local function createVariableNode(model, nodes, browseName, value, nodeId)
  -- Only mandatory Variable attributes
  if not ua.Tools.dataValueValid(value) then
    error(ua.StatusCode.BadNodeAttributesInvalid)
  end


  local rank = ua.ValueRank.Scalar
  if value.IsArray then
    if value.ArrayDimensions and value.ArrayDimensions[1] ~= nil and value.ArrayDimensions[2] == nil then
      rank = ua.ValueRank.OneDimension
    else
      rank = ua.ValueRank.Any
    end
  end

  local node = createBaseNode(model, nodes, ua.NodeClass.Variable, browseName, nodeId)
  -- Confiuring attribute before setting value: value is checked against other attributes
  node.Attrs.DataType = getVariableDataTypeId(value)
  node.Attrs.Rank = rank
  if value.ArrayDimensions then
    node.Attrs.ArrayDimensions = value.ArrayDimensions
  end
  node.Attrs.Value = value

  node.Attrs.Historizing = false
  node.Attrs.AccessLevel = ua.AccessLevel.CurrentReadWrite
  node.Attrs.UserAccessLevel = ua.AccessLevel.CurrentReadWrite
  return node
end

local function createVariableTypeNode(model, nodes, browseName, value, nodeId)
  -- Only mandatory Variable attributes
  local node = createBaseNode(model, nodes, ua.NodeClass.VariableType, browseName, nodeId)
  if value then
    node.Attrs.Value = value
  end
  node.Attrs.DataType = getVariableDataTypeId(value)
  node.Attrs.Rank = ua.ValueRank.Any
  node.Attrs.IsAbstract = false
  return node
end

local function createObjectNode(model, nodes, browseName, nodeId)
  local node = createBaseNode(model, nodes, ua.NodeClass.Object, browseName, nodeId)
  node.Attrs.EventNotifier = 0
  return node
end

local function createObjectTypeNode(model, nodes, browseName, nodeId)
  local node = createBaseNode(model, nodes, ua.NodeClass.ObjectType, browseName, nodeId)
  node.Attrs.IsAbstract = false
  return node
end

local function createMethodNode(model, nodes, browseName, func, nodeId)
  local node = createBaseNode(model, nodes, ua.NodeClass.Method, browseName, nodeId)
  node.Attrs.Executable = true
  node.Attrs.UserExecutable = true
  node.Attrs.NodeCallback = func
  return node
end

local function createDataTypeNode(model, nodes, browseName, nodeId)
  local node = createBaseNode(model, nodes, ua.NodeClass.DataType, browseName, nodeId)
  node.Attrs.IsAbstract = false
  return node
end

local browser = {}

local function newBrowser(model, nodes, node)
  assert(nodes, "Address space empty")

  if node == nil then
    node = nodes[RootNodeId]
  elseif type(node) == "string" then
    node = nodes[node]
  end

  if not node then
    error(ua.StatusCode.BadNodeIdUnknown)
  end

  assert(node, "No root node")

  local obj = {
    Model = model,
    Nodes = nodes,
    Node = node,
    Attrs = node.Attrs
  }

  setmetatable(obj, {__index=browser})

  return obj
end

function browser:children()
  local children = {}
  for _, ref in ipairs(self.Node.Refs) do
    if ref.isForward then
      local targetNode = self.Nodes[ref.target]
      if targetNode then
        tins(children, newBrowser(self.Model, self.Nodes, targetNode))
      end
    end
  end
  return children
end

local function getNode(nodes, nodeId)
  local node = nodes[nodeId]
  if node == nil then
    error(ua.StatusCode.BadNodeIdUnknown)
  end

  return node
end

function browser:path(names)
  local node = self.Nodes:resolvePath(self.Node.Attrs[ua.AttributeId.NodeId], names)
  return newBrowser(self.Model, self.Nodes, node)
end

function browser:getNode(nodeId)
  local node = getNode(self.Nodes, nodeId)
  return newBrowser(self.Model, self.Nodes, node)
end

function browser:objectsFolder(nodeId)
  return self:getNode("i=85")
end

function browser:typesFolder(nodeId)
  return self:getNode("i=86")
end


local function addReference(sourceNode, targetNode, referenceType)
  if not sourceNode.Refs then
    sourceNode.Refs = {}
  end
  if not targetNode.Refs then
    targetNode.Refs = {}
  end

  tins(sourceNode.Refs, {
    isForward = true,
    target = targetNode.Attrs.NodeId,
    type = referenceType,
  })

  tins(targetNode.Refs, {
    isForward = false,
    target = sourceNode.Attrs.NodeId,
    type = referenceType,
  })
end

local function expandHierarchy(startNode, typeNode, model, nodes)
  local newNodes = {}
  local stack = { {type=typeNode, object=startNode} }

  -- Depth-first search around fields of object type
  while #stack > 0 do
    local item = tremove(stack)
    local typeNode = item.type
    local objectNode = item.object

    for _, ref in ipairs(typeNode.Refs) do
      if not ref.isForward and ref.target ~= typeNode.Attrs.NodeId then
        goto continue
      end

      local refNode = nodes[ref.target]
      if not refNode then
        error(ua.StatusCode.BadNodeIdUnknown)
      end

      if ref.type == HasTypeDefinition then
        addReference(objectNode, refNode, ref.type)
      elseif ref.type == HasProperty or ref.type == HasComponent then
        local objectField = nodes:newNode(model:newNodeId(), refNode.Attrs)
        addReference(objectNode, objectField, ref.type)
        tins(newNodes, objectField)
        tins(stack, {type=refNode, object=objectField})
      end

      ::continue::
    end
  end

  for _, node in ipairs(newNodes) do
    nodes:saveNode(node)
  end

end

local addProperty
local addVariable
local addObject
local addMethod
local addField
local setValues
local setInputArguments
local setOutputArguments

local newObject
local newObjectType
local newVariable
local newVariableType
local newMethod
local newReferenceType
local newStructure
local newEnum
local newEditNode
local newDataType


local function getChild(self, propertyName, referenceTypeId, nodeClassMask)
  local element = {
    TargetName = {Name=propertyName},
    ReferenceTypeId = referenceTypeId,
    IsInverse = false,
    IncludeSubtypes = false,
  }

  local node = self.Nodes:resolvePath(self.Node, {element})
  if (node.Attrs.NodeClass & nodeClassMask) == 0 then
    error(ua.StatusCode.BadNodeClassInvalid)
  end
  return node
end

local function getProperty(self, propertyName)
  local node = getChild(self, propertyName, HasProperty, ua.NodeClass.Variable)
  return newEditNode(self, node)
end

local function getComponent(self, propertyName)
  local node = getChild(self, propertyName, HasComponent, ua.NodeClass.Variable | ua.NodeClass.Object)
  return newEditNode(self, node)
end

local function getMethod(self, propertyName)
  local node = getChild(self, propertyName, HasComponent, ua.NodeClass.Method)
  return newEditNode(self, node)
end


addObject = function (self, browseName, objectType, nodeId, refType)
  if objectType == nil then
    objectType = getNode(self.Nodes, BaseObjectTypeNodeId)
  elseif type(objectType) == "string" then
    objectType = getNode(self.Nodes, objectType)
  elseif objectType.Node ~= nil then
    objectType = objectType.Node
  end
  if objectType.Attrs.NodeClass ~= ua.NodeClass.ObjectType then
    error(ua.StatusCode.BadAttributeIdInvalid)
  end

  local newObjectNode = createObjectNode(self.Model, self.Nodes, browseName, nodeId)
  expandHierarchy(newObjectNode, objectType, self.Model, self.Nodes)
  addReference(self.Node, newObjectNode, refType or HasComponent)
  addReference(newObjectNode, objectType, HasTypeDefinition)

  self.Nodes:saveNode(newObjectNode)
  self.Nodes:saveNode(self.Node)

  return newObject(newObjectNode, self.Model, self.Nodes)
end

addVariable = function (self, browseName, value, variableType, nodeId, refType)
  if variableType == nil then
    variableType = getNode(self.Nodes, BaseDataVariableType)
  elseif type(variableType) == "string" then
    variableType = getNode(self.Nodes, variableType)
  end
  if variableType.Attrs.NodeClass ~= ua.NodeClass.VariableType then
    error(ua.StatusCode.BadTypeDefinitionInvalid)
  end
  if variableType.Attrs.IsAbstract == true then
    error(ua.StatusCode.BadTypeDefinitionInvalid)
  end

  if refType == nil then
    refType = HasComponent
  end
  if type(refType) == "string" then
    refType = self.Nodes[refType]
  end
  if refType == nil then
    error(ua.StatusCode.BadReferenceTypeIdInvalid)
  end
  if refType.Attrs.NodeClass ~= ua.NodeClass.ReferenceType then
    error(ua.StatusCode.BadReferenceTypeIdInvalid)
  end

  -- Only mandatory Variable attributes
  local newNode = createVariableNode(self.Model, self.Nodes, browseName, value, nodeId)

  expandHierarchy(newNode, variableType, self.Model, self.Nodes)
  addReference(newNode, variableType, HasTypeDefinition)
  addReference(self.Node, newNode, refType.Attrs.NodeId)

  self.Nodes:saveNode(newNode)

  return newVariable(newNode, self.Model, self.Nodes)
end

addProperty = function (self, browseName, value, nodeId, refType)
  assert(self.Node.Attrs.NodeClass == ua.NodeClass.Object or self.Node.Attrs.NodeClass == ua.NodeClass.ObjectType, "Properties can be added only to objects")
  assert(type(browseName) == "string", "browseName must be a string")
  assert(value and ua.Tools.dataValueValid(value), "value must be valid")

  local newNode = createVariableNode(self.Model, self.Nodes, browseName, value, nodeId)

  local propertyTypeNode = self.Nodes[PropertyTypeIdNodeId]
  addReference(newNode, propertyTypeNode, HasTypeDefinition)
  addReference(self.Node, newNode, refType or HasProperty)

  self.Nodes:saveNode(newNode)
  self.Nodes:saveNode(propertyTypeNode)

  return newVariable(newNode, self.Model, self.Nodes)
end

local function addFolder(self, browseName, nodeId)
  return self:addObject(browseName, FolderTypeId, nodeId, Organizes)
end

local function newArgumentsValue(self, arguments)
  local inputValues = {}
  for _, argument in ipairs(arguments) do
    tins(inputValues, {
        TypeId = ArgumentTypeNodeId,
        Body = {
          Name = argument.Name,
          DataType = argument.DataType,
          ValueRank = argument.ValueRank or ua.ValueRank.Any,
          Description = argument.Description or {},
          ArrayDimensions = argument.ArrayDimensions or {}
        }
    })
  end

  local inputArgumentsValue = {
    Type = ua.VariantType.ExtensionObject,
    IsArray=true,
    Value = inputValues
  }

  return inputArgumentsValue
end

addMethod = function(self, browseName, func, inputArguments, outputArguments)
  assert(type(func) == "function", "no function provided")

  local methodNode = createMethodNode(self.Model, self.Nodes, browseName, func)

  local argumentTypeNode = self.Nodes[ArgumentTypeNodeId]
  local propertyTypeNode = self.Nodes[PropertyTypeIdNodeId]

  local inputArgumentsValue = newArgumentsValue(self, inputArguments)
  local outputArgumentsValue = newArgumentsValue(self, outputArguments)

  local inputArguments = createVariableNode(self.Model, self.Nodes, "InputArguments", inputArgumentsValue)
  inputArguments.Attrs.Rank = ua.ValueRank.OneDimension
  inputArguments.Attrs.ArrayDimensions = {1}
  addReference(inputArguments, propertyTypeNode, HasTypeDefinition)

  local outputArguments = createVariableNode(self.Model, self.Nodes, "OutputArguments", outputArgumentsValue)
  outputArguments.Attrs.Rank = ua.ValueRank.OneDimension
  outputArguments.Attrs.ArrayDimensions = {1}
  addReference(outputArguments, propertyTypeNode, HasTypeDefinition)

  addReference(methodNode, inputArguments, HasProperty)
  addReference(methodNode, outputArguments, HasProperty)
  addReference(self.Node, methodNode, HasComponent)

  self.Nodes:saveNode(inputArguments)
  self.Nodes:saveNode(outputArguments)
  self.Nodes:saveNode(methodNode)

  return newMethod(methodNode, self.Model, self.Nodes)
end

function setInputArguments(self, inputArguments)
  local value = newArgumentsValue(self, inputArguments)
  local inputArguments = self:path{"InputArguments"}
  inputArguments.Attrs.Value = value
  self.Nodes:saveNode(inputArguments)
end

function setOutputArguments(self, outputArguments)
  local value = newArgumentsValue(self, outputArguments)
  local outputArguments = self:path{"OutputArguments"}
  outputArguments.Attrs.Value = value
  self.Nodes:saveNode(outputArguments)
end

addField = function (self, browseName, dataType, rank, defaultValue)
  -- Only mandatory Variable attributes
  local node = self.Node
  local definition = node.Attrs.DataTypeDefinition or {}
  for _, field in ipairs(definition) do
    if field.Name == browseName then
      error(ua.StatusCode.BadAttributeIdInvalid)
    end
  end

  tins(definition, {
    Name = browseName,
    DisplayName = {Text = browseName.Name},
    DataType = dataType,
    ValueRank = rank,
    IsOptional = false,
  })

  node.Attrs.DataTypeDefinition = definition

  self.Nodes:saveNode(node)
end

local function setFields(self, fields)
  local definition = {}
  for _, field in ipairs(fields) do
    tins(definition, field)
  end
  self.Node.Attrs.DataTypeDefinition = definition
  self.Nodes:saveNode(self.Node)
end

local function getField(self, fieldName)
  local definition = self.Node.Attrs.DataTypeDefinition
  for _, field in ipairs(definition) do
    if field.Name == fieldName then
      return field
    end
  end
  error(ua.StatusCode.BadAttributeIdInvalid)
end

local function getFields(self)
  return self.Node.Attrs.DataTypeDefinition
end

function setValues(self, values)
  local definition = {}
  for i, value in ipairs(values) do
    tins(definition, {
      Name = value,
      DisplayName = {Text = value},
      Value = i - 1,
    })
  end
  self.Node.Attrs.DataTypeDefinition = definition
end


local function editPath(self, names)
  local node = self.Nodes:resolvePath(self.Node or RootNodeId, names)
  return newEditNode(self, node)
end

local function newNodeBase(node, model, nodes, base)
  local obj = {
    Node = node,
    Attrs = node.Attrs,
    Model = model,
    Nodes = nodes,
  }
  setmetatable(obj, {__index=base})
  return obj
end

local function getValues(self)
  return self.Node.Attrs.DataTypeDefinition
end

-- All objects must have three fields:
--  Node,
--  Attrs,
--  Model

local Object = {
  addProperty = addProperty,
  addVariable = addVariable,
  addObject = addObject,
  addFolder = addFolder,
  addMethod = addMethod,

  getProperty = getProperty,
  getVariable = getProperty,
  getComponent = getComponent,
  getMethod = getMethod,
  path = editPath
}

local ObjectType = {
  addProperty = addProperty,
  addVariable = addVariable,
  addObject = addObject,
  addFolder = addFolder,
  addMethod = addMethod,

  getProperty = getProperty,
  getVariable = getProperty,
  getComponent = getComponent,
  getMethod = getMethod,
  path = editPath
}

local Variable = {
  addVariable = addVariable,
  getVariable = getProperty,
  path = editPath
}

local VariableType = {
  addVariable = addVariable,
  getVariable = getProperty,
  path = editPath
}

local ReferenceType = {
}

local Structure = {
  addField = addField,
  setFields = setFields,
  getField = getField,
  getFields = getFields,
}

local Enum = {
  setValues = setValues,
  getValues = getValues,
}

function Variable:setValueCallback(func)
  assert(type(func) == "function", "valueCallback must be a function")
  self.Node.Attrs.NodeCallback = func
end

local Method = {
  setInputArguments = setInputArguments,
  setOutputArguments = setOutputArguments,
}

newObject = function(node, model, nodes)
  return newNodeBase(node, model, nodes, Object)
end

newObjectType = function(node, model, nodes)
  return newNodeBase(node, model, nodes, ObjectType)
end

newVariable = function (node, model, nodes)
  return newNodeBase(node, model, nodes, Variable)
end

newVariableType = function(node, model, nodes)
  return newNodeBase(node, model, nodes, VariableType)
end

newMethod = function(node, model, nodes)
  return newNodeBase(node, model, nodes, Method)
end

newReferenceType = function(node, model, nodes)
  return newNodeBase(node, model, nodes, ReferenceType)
end

newStructure = function(node, model, nodes)
  return newNodeBase(node, model, nodes, Structure)
end

newEnum = function(node, model, nodes)
  return newNodeBase(node, model, nodes, Enum)
end

newDataType = function(node, model, nodes)
  if node.BaseId == "i=22" then
    return newStructure(node, model, nodes)
  elseif node.BaseId == "i=29" then
    return newEnum(node, model, nodes)
  else
    error("Unknown data type")
  end
end

local editor = {}

function editor:addObjectType(browseName)
  assert(type(browseName) == "string", "browseName must be a string")

  local objectTypeNode = createObjectTypeNode(self.Model, self.Nodes, browseName)

  local baseObjectTypeNode = self.Nodes[BaseObjectTypeNodeId]
  if not baseObjectTypeNode then
    error("BaseObjectType not found")
  end

  addReference(baseObjectTypeNode, objectTypeNode, HasSubtype)
  self.Nodes:saveNode(objectTypeNode)
  self.Nodes:saveNode(baseObjectTypeNode)

  return newObjectType(objectTypeNode, self.Model, self.Nodes)
end

function editor:addVariableType(browseName)
  local variableTypeNode = createVariableTypeNode(self.Model, self.Nodes, browseName)
  local baseVariableTypeNode = self.Nodes[BaseDataVariableType]
  if not baseVariableTypeNode then
    error("BaseVariableType not found")
  end

  addReference(baseVariableTypeNode, variableTypeNode, HasSubtype)
  self.Nodes:saveNode(variableTypeNode)
  self.Nodes:saveNode(baseVariableTypeNode)

  return newVariableType(variableTypeNode, self.Model, self.Nodes)
end

function editor:addStructure(browseName, nodeId)
  local baseDataTypeNode = self.Nodes[ua.DataTypeId.Structure]
  if not baseDataTypeNode then
    error("BaseDataType not found")
  end

  local dataTypeNode = createDataTypeNode(self.Model, self.Nodes, browseName, nodeId)
  dataTypeNode.BaseId = ua.DataTypeId.Structure
  dataTypeNode.JsonId = self.Model:newNodeId()
  dataTypeNode.BinaryId = self.Model:newNodeId()
  dataTypeNode.DataTypeId = dataTypeNode.Attrs.NodeId
  addReference(baseDataTypeNode, dataTypeNode, HasSubtype)

  local binaryNode = createObjectNode(self.Model, self.Nodes, "Default Binary", dataTypeNode.BinaryId)
  binaryNode.BaseId = dataTypeNode.BaseId
  binaryNode.JsonId = dataTypeNode.JsonId
  binaryNode.BinaryId = dataTypeNode.BinaryId
  binaryNode.DataTypeId = dataTypeNode.DataTypeId
  addReference(dataTypeNode, binaryNode, HasEncoding)

  local baseNodeType = self:getNode('i=76')
  addReference(binaryNode, baseNodeType.Node, HasTypeDefinition)

  local jsonNode = createObjectNode(self.Model, self.Nodes, "Default JSON", dataTypeNode.JsonId)
  binaryNode.BaseId = dataTypeNode.BaseId
  binaryNode.JsonId = dataTypeNode.JsonId
  jsonNode.BinaryId = dataTypeNode.BinaryId
  jsonNode.DataTypeId = dataTypeNode.DataTypeId
  addReference(dataTypeNode, jsonNode, HasEncoding)
  addReference(jsonNode, baseNodeType.Node, HasTypeDefinition)

  self.Nodes:saveNode(dataTypeNode)
  self.Nodes:saveNode(binaryNode)
  self.Nodes:saveNode(jsonNode)
  self.Nodes:saveNode(baseDataTypeNode)

  return newStructure(dataTypeNode, self.Model, self.Nodes)
end


function editor:addEnum(browseName, values, nodeId)
  local baseDataTypeNode = self.Nodes[ua.DataTypeId.Enumeration]
  if not baseDataTypeNode then
    error("BaseEnum not found")
  end

  local dataTypeNode = createDataTypeNode(self.Model, self.Nodes, browseName, nodeId)
  local definition = {}
  for i, value in ipairs(values) do
    tins(definition, {
      Name = value,
      DisplayName = {Text = value},
      Value = i - 1,
    })
  end
  dataTypeNode.Attrs.DataTypeDefinition = definition

  addReference(baseDataTypeNode, dataTypeNode, HasSubtype)

  self.Nodes:saveNode(dataTypeNode)
  self.Nodes:saveNode(baseDataTypeNode)

  return newEnum(dataTypeNode, self.Model, self.Nodes)
end

function editor:addObject(browseName, objectType, nodeId, refType)
  local objects = self:path{"Objects"}
  return objects:addObject(browseName, objectType, nodeId, refType)
end

local nodeFactoryMap <const> = {
  [ua.NodeClass.Object] = newObject,
  [ua.NodeClass.ObjectType] = newObjectType,
  [ua.NodeClass.Variable] = newVariable,
  [ua.NodeClass.VariableType] = newVariableType,
  [ua.NodeClass.Method] = newMethod,
  [ua.NodeClass.ReferenceType] = newReferenceType,
  [ua.NodeClass.DataType] = newDataType,
}

newEditNode = function(self, node)
  if type(node) == "string" then
    node = getNode(self.Nodes, node)
  end

  local factory = nodeFactoryMap[node.Attrs.NodeClass]
  if not factory then
    error(ua.StatusCode.BadNodeIdUnknown)
  end
  self.Nodes:saveNode(node)
  return factory(node, self.Model, self.Nodes)
end

function editor:findNode(node)
  if type(node) == "string" then
    node = self.Nodes[node]
  end
  if node == nil then
    return nil
  end
  return newEditNode(self, node)
end

editor.getNode = newEditNode

editor.path = editPath

function editor:objectsFolder()
  return self:getNode("i=85")
end

function editor:typesFolder()
  return self:getNode("i=86")
end

function editor:save()
  self.Nodes:save()
end

return {
  newBrowser = newBrowser,
  newEditor = function(model)
    local newEditor = {
      Model = model,
      Nodes = address_space_create(model.Nodes),
    }
    setmetatable(newEditor, {__index=editor})
    return newEditor
  end
}
