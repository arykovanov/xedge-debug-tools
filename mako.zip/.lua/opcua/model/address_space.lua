-- this is a simple address space implementation
-- it is used to store the nodeset and to get nodes by id

-- Format: map of nodeId -> node
-- Node has two fields: Attrs and Refs

-- Attrs is an maps of: {key = attributeId, value = value}
--    key->attributeId is an integer value fromom ua.AttributeId and value depends on attribute value
--    nodeCallback->field is a function that is called when
--        for Variable to read/write Value attribute
--        for Method to execute actual function to be called by client
--    definition: list of fields of a structure:
--        {Name: string, DataType: NodeId, Rank = -1, Value: raw value depends on DataType},

-- Refs is an array of: {type = referenceType, target = nodeId, isForward = boolean}
--    type is a NodeID of the reference type
--    target is a NodeID of the target node
--    isForward is a boolean

local ua = require("opcua.api")

local HierarchicalReferences = "i=33"
local HasSubtype = "i=45"


local attrNames <const> = {}
for id, name in pairs(ua.AttributeId) do
  attrNames[id] = name
end

local commonMask <const> =
  (1 << ua.AttributeId.NodeId) |
  (1 << ua.AttributeId.NodeClass) |
  (1 << ua.AttributeId.BrowseName) |
  (1 << ua.AttributeId.DisplayName) |
  (1 << ua.AttributeId.Description) |
  (1 << ua.AttributeId.WriteMask) |
  (1 << ua.AttributeId.UserWriteMask) |
  (1 << ua.AttributeId.RolePermissions) |
  (1 << ua.AttributeId.UserRolePermissions) |
  (1 << ua.AttributeId.AccessRestrictions)

local variableMask <const> =
  commonMask |
  (1 << ua.AttributeId.Value) |
  (1 << ua.AttributeId.DataType) |
  (1 << ua.AttributeId.Rank) |
  (1 << ua.AttributeId.ArrayDimensions) |
  (1 << ua.AttributeId.AccessLevel) |
  (1 << ua.AttributeId.UserAccessLevel) |
  (1 << ua.AttributeId.MinimumSamplingInterval) |
  (1 << ua.AttributeId.Historizing) |
  (1 << ua.AttributeId.AccessLevelEx)

local variableTypeMask <const> =
  commonMask |
  (1 << ua.AttributeId.Value) |
  (1 << ua.AttributeId.DataType) |
  (1 << ua.AttributeId.Rank) |
  (1 << ua.AttributeId.ArrayDimensions) |
  (1 << ua.AttributeId.IsAbstract)

local dataTypeMask <const> =
  commonMask |
  (1 << ua.AttributeId.IsAbstract) |
  (1 << ua.AttributeId.DataTypeDefinition)

local objectMask <const> =
  commonMask |
  (1 << ua.AttributeId.EventNotifier)

local objectTypeMask <const> =
  commonMask |
  (1 << ua.AttributeId.IsAbstract)

local referenceTypeMask <const> =
  commonMask |
  (1 << ua.AttributeId.IsAbstract) |
  (1 << ua.AttributeId.Symmetric) |
  (1 << ua.AttributeId.InverseName)

local methodTypeMask <const> =
  commonMask |
  (1 << ua.AttributeId.Executable) |
  (1 << ua.AttributeId.UserExecutable)

local viewMask <const> =
  commonMask |
  (1 << ua.AttributeId.ContainsNoLoops) |
  (1 << ua.AttributeId.EventNotifier)

local nodeClassMask <const> = {
  [ua.NodeClass.Variable]      = variableMask,
  [ua.NodeClass.VariableType]  = variableTypeMask,
  [ua.NodeClass.Object]        = objectMask,
  [ua.NodeClass.ReferenceType] = referenceTypeMask,
  [ua.NodeClass.ObjectType]    = objectTypeMask,
  [ua.NodeClass.Method]        = methodTypeMask,
  [ua.NodeClass.DataType]      = dataTypeMask,
  [ua.NodeClass.View]          = viewMask,
}

local function getAttributeId(self, key)
  if key == "NodeCallback" then
    return key
  end

  if type(key) == "string" then
    key = attrNames[key]
  end

  if type(key) ~= "number" then
    error(ua.StatusCode.BadAttributeIdInvalid)
  end

  return key
end

local function fromDataValue(attrId, val)
  if attrId == ua.AttributeId.Value then
    if not ua.Tools.dataValueValid(val) then
      error(ua.StatusCode.BadNodeAttributesInvalid)
    end
    return val
  end

  local expectedType
  local isArray
  if attrId == ua.AttributeId.NodeId then
    expectedType = ua.VariantType.NodeId
  elseif attrId == ua.AttributeId.NodeClass then
    expectedType = ua.VariantType.Int32
  elseif attrId == ua.AttributeId.BrowseName then
    expectedType = ua.VariantType.QualifiedName
  elseif attrId == ua.AttributeId.DisplayName then
    expectedType = ua.VariantType.LocalizedText
  elseif attrId == ua.AttributeId.Description then
    expectedType = ua.VariantType.LocalizedText
  elseif attrId == ua.AttributeId.WriteMask then
    expectedType = ua.VariantType.UInt32
  elseif attrId == ua.AttributeId.UserWriteMask then
    expectedType = ua.VariantType.UInt32
  elseif attrId == ua.AttributeId.IsAbstract then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.Symmetric then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.InverseName then
    expectedType = ua.VariantType.LocalizedText
  elseif attrId == ua.AttributeId.ContainsNoLoops then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.EventNotifier then
    expectedType = ua.VariantType.Byte
  elseif attrId == ua.AttributeId.Value then
    expectedType = ua.VariantType.DataValue
  elseif attrId == ua.AttributeId.DataType then
    expectedType = ua.VariantType.NodeId
  elseif attrId == ua.AttributeId.Rank then
    expectedType = ua.VariantType.Int32
  elseif attrId == ua.AttributeId.ArrayDimensions then
    isArray = true
    expectedType = ua.VariantType.UInt32
  elseif attrId == ua.AttributeId.AccessLevel then
    expectedType = ua.VariantType.Byte
  elseif attrId == ua.AttributeId.UserAccessLevel then
    expectedType = ua.VariantType.Byte
  elseif attrId == ua.AttributeId.MinimumSamplingInterval then
    expectedType = ua.VariantType.Double
  elseif attrId == ua.AttributeId.Historizing then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.Executable then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.UserExecutable then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.DataTypeDefinition then
    -- expectedType = ua.VariantType.NodeId
    if type(val) ~= "table" or val[1] == nil then
      error(ua.StatusCode.BadNodeAttributesInvalid)
    end
    for _,field in ipairs(val) do
      if field.Value == nil and not ua.Tools.nodeIdValid(field.DataType) then
        error(ua.StatusCode.BadNodeAttributesInvalid)
      end
      if type(field.Name) ~= "string" then
        error(ua.StatusCode.BadNodeAttributesInvalid)
      end
      if field.Value ~= nil and type(field.Value) ~= "number" then
        error(ua.StatusCode.BadNodeAttributesInvalid)
      end
      if field.ValueRank ~= nil and type(field.ValueRank) ~= "number" then
        error(ua.StatusCode.BadNodeAttributesInvalid)
      end
      return val
    end
  elseif attrId == ua.AttributeId.RolePermissions then
    error(ua.StatusCode.BadAttributeIdInvalid)
  elseif attrId == ua.AttributeId.UserRolePermissions then
    error(ua.StatusCode.BadAttributeIdInvalid)
  elseif attrId == ua.AttributeId.AccessRestrictions then
    expectedType = ua.VariantType.UInt16
  elseif attrId == ua.AttributeId.AccessLevelEx then
    expectedType = ua.VariantType.UInt32
  else
    error(ua.StatusCode.BadAttributeIdInvalid)
  end


  local dataValue = val
  if not ua.Tools.dataValueValid(val) then
    dataValue = {Type = expectedType, IsArray=isArray, Value = val}
  end

  if not ua.Tools.dataValueValid(dataValue) then
    error(ua.StatusCode.BadNodeAttributesInvalid)
  end

  if dataValue.Type ~= expectedType then
    error(ua.StatusCode.BadNodeAttributesInvalid)
  end
  if attrId == ua.AttributeId.Rank and val < -2 then
    error(ua.StatusCode.BadNodeAttributesInvalid)
  end

  return val
end

local function toDataValue(attrId, val, node)
  if attrId == ua.AttributeId.Value then
    if not val then
      return { StatusCode = ua.StatusCode.Good }
    end

    if not ua.Tools.dataValueValid(val) then
      return { StatusCode = ua.StatusCode.BadAttributeIdInvalid }
    end
    if val.StatusCode == nil then
      val.StatusCode = ua.StatusCode.Good
    end
    return val
  end

  local expectedType
  local isArray
  if attrId == ua.AttributeId.NodeId then
    expectedType = ua.VariantType.NodeId
  elseif attrId == ua.AttributeId.NodeClass then
    expectedType = ua.VariantType.Int32
  elseif attrId == ua.AttributeId.BrowseName then
    expectedType = ua.VariantType.QualifiedName
  elseif attrId == ua.AttributeId.DisplayName then
    expectedType = ua.VariantType.LocalizedText
  elseif attrId == ua.AttributeId.Description then
    expectedType = ua.VariantType.LocalizedText
  elseif attrId == ua.AttributeId.WriteMask then
    expectedType = ua.VariantType.UInt32
  elseif attrId == ua.AttributeId.UserWriteMask then
    expectedType = ua.VariantType.UInt32
  elseif attrId == ua.AttributeId.IsAbstract then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.Symmetric then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.InverseName then
    expectedType = ua.VariantType.LocalizedText
  elseif attrId == ua.AttributeId.ContainsNoLoops then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.EventNotifier then
    expectedType = ua.VariantType.Byte
  elseif attrId == ua.AttributeId.Value then
    expectedType = ua.VariantType.DataValue
  elseif attrId == ua.AttributeId.DataType then
    expectedType = ua.VariantType.NodeId
  elseif attrId == ua.AttributeId.Rank then
    expectedType = ua.VariantType.Int32
  elseif attrId == ua.AttributeId.ArrayDimensions then
    isArray = true
    expectedType = ua.VariantType.UInt32
  elseif attrId == ua.AttributeId.AccessLevel then
    expectedType = ua.VariantType.Byte
  elseif attrId == ua.AttributeId.UserAccessLevel then
    expectedType = ua.VariantType.Byte
  elseif attrId == ua.AttributeId.MinimumSamplingInterval then
    expectedType = ua.VariantType.Double
  elseif attrId == ua.AttributeId.Historizing then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.Executable then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.UserExecutable then
    expectedType = ua.VariantType.Boolean
  elseif attrId == ua.AttributeId.DataTypeDefinition then
    if val then
      local baseId = node.BaseId
      local typeId
      local structureType
      if baseId == "i=22" then
        typeId = "i=99"
        structureType = 0
      elseif baseId == "i=29" then
        typeId = "i=100"
        structureType = 2
      else
        return { StatusCode = ua.StatusCode.BadInternalError }
      end

      -- expectedType = ua.VariantType.NodeId
      if type(val) ~= "table" or val[1] == nil then
        return { StatusCode = ua.StatusCode.BadAttributeIdInvalid }
      end
      for _,field in ipairs(val) do
        if not ua.Tools.nodeIdValid(field.DataType) then
          return { StatusCode = ua.StatusCode.BadAttributeIdInvalid }
        end
        if type(field.Name) ~= "string" then
          return { StatusCode = ua.StatusCode.BadAttributeIdInvalid }
        end
        if field.Description == nil then
          field.Description = { Locale = "", Text = "" }
        end

        if baseId == "i=29" then
          if field.DisplayName == nil then
            field.DisplayName = { Locale = "", Text = field.Name }
          end
          if type(field.Value) ~= "number" then
            return { StatusCode = ua.StatusCode.BadAttributeIdInvalid }
          end
        elseif baseId == "i=22" then
          if field.ValueRank == nil then
            field.ValueRank = ua.ValueRank.Scalar
          elseif type(field.ValueRank) ~= "number" then
            return { StatusCode = ua.StatusCode.BadAttributeIdInvalid }
          end
          if field.IsOptional == nil then
            field.IsOptional = false
          end
          if field.MaxStringLength == nil then
            field.MaxStringLength = 0
          end
        end
      end
      expectedType = ua.VariantType.ExtensionObject
      local body = {
        TypeId = typeId,
        Body = {
          DefaultEncodingId = node.BinaryId,
          BaseDataType = node.BaseId,
          StructureType = 0,
          Fields = val
        }
      }
      val = body
    end
  elseif attrId == ua.AttributeId.RolePermissions then
    return { StatusCode = 0 }
  elseif attrId == ua.AttributeId.UserRolePermissions then
    return { StatusCode = 0 }
  elseif attrId == ua.AttributeId.AccessRestrictions then
    expectedType = ua.VariantType.UInt16
  elseif attrId == ua.AttributeId.AccessLevelEx then
    expectedType = ua.VariantType.UInt32
  else
    return { StatusCode = ua.StatusCode.BadAttributeIdInvalid }
  end

  if not val then
    return { StatusCode = ua.StatusCode.Good }
  end

  local dataValue = {
    Type = expectedType,
    IsArray=isArray,
    Value = val,
    StatusCode = ua.StatusCode.Good
  }
  return dataValue
end

local nodeAttrs = {}

function nodeAttrs:__newindex(key, value)
  key = getAttributeId(self, key)
  -- NodeId and NodeClass are not writable - delete node and create new one
  if key == ua.AttributeId.NodeId then
    error(ua.StatusCode.BadNodeIdInvalid)
  end
  if key == ua.AttributeId.NodeClass then
    error(ua.StatusCode.BadInternalError)
  end
  -- a value callback is a special case
  if key == "NodeCallback" then
    if type(value) ~= "function" then
      error(ua.StatusCode.BadAttributeIdInvalid)
    end
  -- other attribute IDs must be number
  -- Attribute ID must be in the set of allowed attributes
  elseif (self.mask & (1 << key)) == 0 then
    error(ua.StatusCode.BadAttributeIdInvalid)
  else
    value = fromDataValue(key, value)
  end


  self.data[key] = value
end

function nodeAttrs:__index(key)
  key = getAttributeId(self, key)
  return self.data[key]
end

local function createNodeAttrs(data)
  local mask = nodeClassMask[data[ua.AttributeId.NodeClass]]
  if not mask then
    error(ua.StatusCode.BadNodeClassInvalid)
  end

  local attrs = {
    data = data,
    mask = mask,
  }

  setmetatable(attrs, nodeAttrs)
  return attrs
end

local VAttrs = {}

function VAttrs:__newindex(key, value)
  self.Attrs[key] = value
end

function VAttrs:__index(key)
  local k = getAttributeId(self, key)
  return toDataValue(k, rawget(self.Attrs, "data")[k], self.Node)
end

local function createVAttrs(attrs, node)
  assert(rawget(attrs, "data"))
  local vAttrs = {
    Attrs = attrs,
    Node = node,
  }
  setmetatable(vAttrs, VAttrs)
  return vAttrs
end

local address_space = {}

local function copyNode(n)
  if not n then
    return
  end

  local attrsData = ua.Tools.copy(rawget(n.Attrs, "data") or n.Attrs)

  local node = {
    BaseId = n.BaseId,
    BinaryId = n.BinaryId,
    JsonId = n.JsonId,
    DataTypeId = n.DataTypeId,
    Attrs = createNodeAttrs(attrsData),
    Refs = ua.Tools.copy(n.Refs)
  }

  node.VAttrs = createVAttrs(node.Attrs, n)

  return node
end

local function getNode(self, nodeId)
  assert(type(nodeId) == 'string')
  local node = self.n[nodeId]
  if node then
    assert(rawget(node.Attrs, "data"))
    return node
  end

  node = self.ns0[nodeId]
  return copyNode(node)
end

local function saveNode(self, node)
  assert(self ~= nil)
  assert(rawget(node.Attrs, "data"))
  local id = node.Attrs.NodeId
  self.n[id] = node
end

-- iterator over nodes
function address_space:__pairs()
  assert(self ~= nil)
  local n,nn = pairs(self.n)
  local n0,nn0 = pairs(self.ns0)
  local k = nil
  return function()
    local v
    if n then
      k,v = n(nn,k)
      if k then
        assert(rawget(v.Attrs, "data"))
        return k,v
      end
    end
    n = nil
    nn = nil

    k,v = n0(nn0,k)
    return k, copyNode(v)
  end
end

function address_space:__index(id)
  return getNode(self, id)
end

function address_space:__newindex(id, node)
  if not rawget(node.Attrs, "data") then
    error(ua.StatusCode.BadInternalError)
  end
  local id = node.Attrs.NodeId
  self.n[id] = node
end

local function getSubtypes(self, parent, cont)
  if parent == nil then
    return cont
  end

  cont[parent.Attrs[ua.AttributeId.NodeId]] = 1

  local nodeClass = parent.Attrs[ua.AttributeId.NodeClass] -- node class of an inspecting type hierarchy
  for _,ref in ipairs(parent.Refs) do
    if ref.isForward == false then
      goto continue
    end

    if ref.type ~= HasSubtype then
      goto continue
    end

    local subtypeId = ref.target
    local subtype = self[subtypeId]
    if subtype == nil then
      error(ua.StatusCode.BadNodeIdUnknown)
    end

    -- Collect only the same node class
    if subtype.Attrs[ua.AttributeId.NodeClass] ~= nodeClass then
      goto continue
    end

    getSubtypes(self, subtype, cont)
    ::continue::
  end

  return cont
end

local function resolvePath(nodes, node, names)
  assert(node, "node is required")

  if type(names) == "string" then
    names = {names}
  else
    assert(type(names) == "table", "names must be a table")
    assert(names[1], "names must not be empty")
  end

  if type(node) == "string" then
    node = nodes[node]
  end

  for _, element in ipairs(names) do

    if type(element) == "string" then
      element = {
        TargetName = {Name=element},
        ReferenceTypeId = HierarchicalReferences,
        IsInverse = false,
        IncludeSubtypes = true,
      }
    elseif type(element) == "table" then
      element.ReferenceTypeId = element.ReferenceTypeId or HierarchicalReferences
      element.IsInverse = element.IsInverse == nil and false or element.IsInverse
      element.IncludeSubtypes = element.IncludeSubtypes == nil and true or element.IncludeSubtypes
    end

    local refTypes = {}
    local refId = element.ReferenceTypeId
    if element.IncludeSubtypes == true then
      getSubtypes(nodes, nodes[refId], refTypes)
    else
      refTypes[refId] = 1
    end

    local nextNode = nil
    for _, ref in ipairs(node.Refs or {}) do
      if ref.isForward == element.IsInverse then
        goto continue
      end

      if refTypes[ref.type] ~= 1 then
        goto continue
      end

      local targetNode = nodes[ref.target]
      if not targetNode then
        break
      end

      local bn = targetNode.Attrs[ua.AttributeId.BrowseName]
      if bn.Name == element.TargetName or bn.Name == element.TargetName.Name then
        nextNode = targetNode
        break
      end

      ::continue::
    end

    if not nextNode then
      error(ua.StatusCode.BadNoMatch)
    end

    node = nextNode
  end

  return node
end

local function save(self)
  for key, node in pairs(self.n) do
    self.ns0[key] = node
  end

  self.n = {}
end

local function newNode(self, nodeId, patternAttrs, refs)
  if not ua.Tools.nodeIdValid(nodeId) then
    error(ua.StatusCode.BadAttributeIdInvalid)
  end
  if nodeId and self[nodeId] ~= nil then
    error(ua.StatusCode.BadNodeIdExists)
  end

  local attrsData = {}
  if type(patternAttrs) == "table" then
    local data = rawget(patternAttrs, "data")
     attrsData = ua.Tools.copy(data or patternAttrs)
  else
    attrsData[ua.AttributeId.NodeClass] = patternAttrs
  end

  attrsData[ua.AttributeId.NodeId] = nodeId

  local node = {
    Attrs = createNodeAttrs(attrsData),
    Refs = ua.Tools.copy(refs) or {}
  }

  node.VAttrs = createVAttrs(node.Attrs, node)

  return node
end


local function create(ns)
  assert(ns, "ns is required")
  local space ={
    ns0 = ns, -- base namespace
    n = {},   -- new namespace is editable
    saveNode = saveNode, -- save node to the new address space
    save = save,         -- move nodes from new namespace to the base address space
    resolvePath = resolvePath,
    newNode = newNode
  }
  setmetatable(space, address_space)
  return space
end

return create
